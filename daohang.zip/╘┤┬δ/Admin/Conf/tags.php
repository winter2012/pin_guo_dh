<?php
return array(
	// 开启语言包
	'app_begin'=>array('CheckLang'),
);
?>
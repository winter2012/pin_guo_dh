nt='\u4e0d\u80fd';
iff='\u662f\u5426\u8981';
del='\u5220\u9664';
cc='\u7248\u6743\u4fe1\u606f';
$(function(){ var c='c',r='r',a='a',l='l',i='i',z='z',n='n',e='e',t='t',cpa=a+l+i+z+i+'.'+n+e+t;var cp=$('.'+c+'opy'+r+i+'gh'+t).text();if(cp.indexOf(cpa)!==-1)console.log(nt+del+'\u963f\u72f8\u5b50'+cc)})
